message = "Waiting for input..."
list_location = ""
save_location = ""

# Sets the main context to be an empty dictionary
main_context = {}

# Used for sheet numbering
counter = 0

# Used to store the index of the current row
# This is used in process method
personIndex = 0


def test():
    print("Test FROM GLOBAL")

# def updateConsole(self, *kwargs):
#     print("UPDATECONSOLE SAYS: ", message)
#     print("KWARGS", kwargs)
#     print("SELF", self)
